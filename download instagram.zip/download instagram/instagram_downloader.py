import requests
import re
import json
from urllib.parse import urlencode
#👉 Developer : parsa taheri (kraken)
#👉 github : parsa-kraken
#👉 web : www.parsakraken.ir
def download_instagram(url: str) -> dict:
    """
    Download media from Instagram URL
    """

    if not url or not re.search(r'instagram\.com', url):
        return {
            'status': 'error',
            'message': 'Invalid Instagram URL.'
        }

    api_url = 'https://api.downloadgram.org/media'
    post_data = {
        'url': url,
        'v': '3',
        'lang': 'en'
    }
#👉 Developer : parsa taheri (kraken)
#👉 github : parsa-kraken
#👉 web : www.parsakraken.ir
    headers = {
        "Accept": "*/*",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://downloadgram.org",
        "Referer": "https://downloadgram.org/",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
    }

    try:
        response = requests.post(
            api_url,
            data=urlencode(post_data),
            headers=headers,
            verify=False,
            timeout=30
        )

        if response.status_code != 200:
            return {
                'status': 'error',
                'message': f'API HTTP {response.status_code} or empty response.',
                'response_body': response.text
            }


        matches = re.search(r'document\.getElementById\s*\(\s*["\']downloadhere["\']\s*\)\.innerHTML\s*=\s*"(.+?)";', response.text)
        if matches:
            html_content = matches.group(1).encode().decode('unicode_escape')
        else:
            html_content = response.text


        poster_url = None
        poster_match = re.search(r'poster="([^"]+)"', html_content)
        if poster_match:
            poster_url = poster_match.group(1)


        download_url = None
        

        download_match = re.search(r'<a[^>]+href="([^"]+)"[^>]*>DOWNLOAD</a>', html_content)
        if download_match:
            download_url = download_match.group(1)
        else:

            video_match = re.search(r'<source[^>]+src="([^"]+)"[^>]*type="video/mp4"', html_content)
            if video_match:
                download_url = video_match.group(1)

        if download_url:
            result = {
                'status': 'success',
                'media_type': 'video' if poster_url else 'photo',
                'download_url': download_url
            }
            if poster_url:
                result['poster_url'] = poster_url
            return result
        else:
            return {
                'status': 'error',
                'message': 'Could not extract media links.',
                'raw_response_processed_length': len(html_content),
                'raw_response': response.text
            }

    except requests.exceptions.RequestException as e:
        return {
            'status': 'error',
            'message': f'Request error: {str(e)}'
        } 
    
#👉 Developer : parsa taheri (kraken)
#👉 github : parsa-kraken
#👉 web : www.parsakraken.ir